import { ExtensionContext, commands, extensions, window, StatusBarAlignment } from 'vscode'
import { vsHelp } from '../utils/vsHelp'
import { setContext } from '../utils/global'
import { PickList } from './PickList'
import ReaderViewProvider from './readerView'

// "configuration": {
//       "title": "背景配置",
//       "properties": {
//         "binBgConfig.opacity": {
//           "type": "number",
//           "maximum": 1,
//           "minimum": 0,
//           "default": 0.2,
//           "description": "Background opacity (0 - 1) / 背景透明度(0 - 1)"
//         },
//         "binBgConfig.imagePath": {
//           "type": "string",
//           "default": "",
//           "description": "Background image path / 背景图片路径"
//         },
//         "binBgConfig.randomImageFolder": {
//           "type": "string",
//           "default": "",
//           "description": "Background image's folder path for random / 图片目录"
//         },
//         "binBgConfig.autoStatus": {
//           "type": "boolean",
//           "default": false,
//           "description": "Automatically change background each time you start / 每次启动时随机自动更换背景"
//         },
//         "binBgConfig.sizeModel": {
//           "type": "string",
//           "default": "cover",
//           "description": "Background image size adaptive mode / 图片尺寸适应模式"
//         },
//         "binBgConfig.defaultOnlinePage": {
//           "type": "string",
//           "default": "https://vs.20988.xyz/d/24-vscodebei-jing-tu-tu-ku",
//           "description": "Online images default page / 在线图库默认页面"
//         }
//       }
//     },
// {
//   "command": "vsc.bg.start",
//   "title": "bg - start"
// },
// {
//   "command": "vsc.bg.refresh",
//   "title": "backgroundCover - refresh"
// }

// 插件入口文件
function main(context: ExtensionContext) {
  // 创建底部按钮
  let backImgBtn = window.createStatusBarItem(StatusBarAlignment.Right, -999)
  backImgBtn.text = '$(circuit-board)' // '$(file-media)'
  backImgBtn.command = 'vsc.bg.start'
  backImgBtn.tooltip = '背景图设置'
  backImgBtn.show()
  PickList.autoUpdateBackground()

  // 注册两个控制命令
  let randomCommand = commands.registerCommand('vsc.bg.refresh', () => {
    PickList.randomUpdateBackground()
  })
  let startCommand = commands.registerCommand('vsc.bg.start', () => {
    PickList.createItemList()
  })
  context.subscriptions.push(startCommand)
  context.subscriptions.push(randomCommand)

  // 监听主题变化
  window.onDidChangeActiveColorTheme(event => {
    PickList.autoUpdateBlendModel(event.kind)
  })
  // webview
  // const readerViewProvider = new ReaderViewProvider()
  // window.registerWebviewViewProvider('vsc.bg.readerView', readerViewProvider, {
  //   webviewOptions: {
  //     retainContextWhenHidden: true,
  //   },
  // })
  // commands.registerCommand('vsc.bg.refreshEntry', () => readerViewProvider.refresh())
  // commands.registerCommand('vsc.bg.home', () => readerViewProvider.home())

  // 首次打开的提示
  // let openVersion: string | undefined = context.globalState.get('ext_version')
  // let ex: Extension<any> | undefined = extensions.getExtension('wangbin.bin-vsc-helper')
  // console.log('openVersion ========>', openVersion)
  // console.log('ex ========>', ex)

  // let version: string = ex ? ex.packageJSON['version'] : ''
  // let title: string = ex ? ex.packageJSON['one_title'] : ''
  // console.log('version ========>', version)
  // console.log('title ========>', title)

  // if (openVersion !== version && title !== '') {
  //   context.globalState.update('ext_version', version)
  //   vsHelp.showInfo('🐷欢迎使用背景图插件🐷' + version)
  // }

  setContext(context)
}

export { main }
